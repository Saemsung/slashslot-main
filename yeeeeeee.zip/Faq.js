document.addEventListener("DOMContentLoaded", () => {
    const questions = document.querySelectorAll(".faq-question");

    questions.forEach((question) => {
        question.addEventListener("click", () => {
            const answerContainer = question.nextElementSibling;

            // Chiude tutte le altre risposte prima di aprire quella corrente
            document.querySelectorAll(".faq-answer-container").forEach((container) => {
                if (container !== answerContainer) {
                    container.style.maxHeight = "0";  // Chiude altre risposte
                    container.classList.remove("show");
                }
            });

            // Alterna la visibilità della risposta corrente
            answerContainer.classList.toggle("show");

            if (answerContainer.classList.contains("show")) {
                // Calcola l'altezza massima in base al contenuto e la assegna
                answerContainer.style.maxHeight = answerContainer.scrollHeight + "px";
            } else {
                // Chiude la risposta
                answerContainer.style.maxHeight = "0";
            }
        });
    });

    // Animazione di apparizione delle FAQ
    const faqItems = document.querySelectorAll(".faq-item");
    faqItems.forEach((item, index) => {
        item.style.opacity = 0;  // Inizializza l'opacità a 0
        item.style.transform = "translateY(20px)";  // Sposta l'elemento verso il basso
        setTimeout(() => {
            item.style.opacity = 1;  // Imposta l'opacità a 1 per l'effetto di apparizione
            item.style.transform = "translateY(0)";  // Riporta l'elemento nella posizione originale
            item.style.transition = "opacity 0.5s ease, transform 0.5s ease";  // Aggiungi la transizione
        }, index * 100); // Effetto di cascata per l'apparizione
    });
});
