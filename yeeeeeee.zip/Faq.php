<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQ - Casinò</title>
    <link rel="stylesheet" href="Faq.css">
    <script src="Faq.js" defer></script>
    <style>
        /* Aggiunta di stili CSS per la visibilità delle risposte */
        .faq-answer-container {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.5s ease;
        }
        .faq-answer-container.show {
            max-height: 200px; /* Regola l'altezza massima se necessario */
        }
        .faq-item {
            margin-bottom: 10px; /* Spaziatura tra gli item delle FAQ */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Domande Frequenti (FAQ)</h1>
        <div class="faq">
            <div class="faq-item">
                <h2 class="faq-question">1. Quali sono i tipi di casinò disponibili?</h2>
                <div class="faq-answer-container">
                    <p class="faq-answer">Ci sono diversi tipi di casinò, tra cui casinò fisici, casinò online e casinò dal vivo. Ogni tipo offre un'esperienza unica.</p>
                </div>
            </div>
            <div class="faq-item">
                <h2 class="faq-question">2. Come posso scegliere un casinò online sicuro?</h2>
                <div class="faq-answer-container">
                    <p class="faq-answer">Per scegliere un casinò online sicuro, verifica che sia autorizzato e regolamentato, leggi le recensioni degli utenti e controlla i metodi di pagamento disponibili.</p>
                </div>
            </div>
            <div class="faq-item">
                <h2 class="faq-question">3. I giochi dei casinò online sono equi?</h2>
                <div class="faq-answer-container">
                    <p class="faq-answer">Sì, i giochi dei casinò online sono equi se sono offerti da casinò autorizzati e utilizzano un generatore di numeri casuali (RNG) certificato.</p>
                </div>
            </div>
            <div class="faq-item">
                <h2 class="faq-question">4. Come posso depositare denaro nel mio conto di casinò online?</h2>
                <div class="faq-answer-container">
                    <p class="faq-answer">Puoi depositare denaro utilizzando vari metodi come carte di credito, portafogli elettronici e bonifici bancari. Controlla i metodi disponibili nel casinò scelto.</p>
                </div>
            </div>
            <div class="faq-item">
                <h2 class="faq-question">5. Posso giocare gratuitamente nei casinò online?</h2>
                <div class="faq-answer-container">
                    <p class="faq-answer">Sì, molti casinò online offrono modalità di gioco gratuite per permetterti di provare i giochi senza rischiare denaro reale.</p>
                </div>
            </div>
            <div class="faq-item">
                <h2 class="faq-question">6. Come posso prelevare le mie vincite?</h2>
                <div class="faq-answer-container">
                    <p class="faq-answer">Per prelevare le tue vincite, vai alla sezione prelievi del tuo conto e scegli il metodo di prelievo. I tempi di elaborazione possono variare a seconda del metodo scelto.</p>
                </div>
            </div>
            <div class="faq-item">
                <h2 class="faq-question">7. Cosa devo fare se ho un problema con il mio conto?</h2>
                <div class="faq-answer-container">
                    <p class="faq-answer">Se hai un problema con il tuo conto, contatta il servizio clienti del casinò. Sono disponibili tramite chat dal vivo, email o telefono.</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
