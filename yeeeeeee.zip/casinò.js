// Aggiungi l'animazione di fade-in quando la pagina viene caricata o aggiornata
window.addEventListener('load', function() {
    document.body.classList.add('fade-in');
});

// Animazioni per lo scorrimento dolce
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Funzione per filtrare i casinò in base all'input dell'utente
const casinos = [
    { name: "Casino Royale" },
    { name: "Caesar's Palace" },
    { name: "Crown Casino" },
    { name: "Casino de Paris" },
    { name: "Caesars Windsor" },
    { name: "Casino Barcelona" },
    { name: "Casino Lisboa" },
    { name: "MGM Grand" },
    { name: "Bellagio" },
    { name: "Wynn Las Vegas" },
    { name: "The Venetian" },
    { name: "Hard Rock Hotel" },
    { name: "Rio All-Suite Hotel" },
    { name: "The Mirage" },
    { name: "Excalibur" },
    { name: "Luxor" },
    { name: "Treasure Island" },
    { name: "New York-New York" },
    { name: "Paris Las Vegas" },
    { name: "Planet Hollywood" },
    { name: "Encore" },
    { name: "Aria Resort" },
    { name: "Bally's" },
    { name: "Flamingo" },
    { name: "O'Sheas" },
    { name: "Palace Station" },
    { name: "Silverton Casino" },
    { name: "Green Valley Ranch" },
    { name: "The LINQ" },
    { name: "Downtown Grand" },
    { name: "Golden Nugget" },
    { name: "Binion's" },
    { name: "The D" },
    { name: "Fremont" },
    { name: "Plaza" },
    { name: "The STRAT" },
    { name: "Tropicana" },
    { name: "South Point" },
    { name: "El Cortez" },
    { name: "Sam's Town" },
    { name: "Las Vegas Club" },
    { name: "The Orleans" },
    { name: "Suncoast" },
    { name: "Westgate" },
    { name: "Circus Circus" },
    { name: "Sahara" },
    { name: "The Westin" },
    { name: "Hotel Arizona" },
    { name: "Luxe Hotel" },
    { name: "New Tropicana" },
    { name: "Elara" },
    { name: "Vdara" },
    { name: "Aqua" },
    { name: "Resorts World" }
];

const searchInput = document.getElementById('casino-search'); // Assicurati di avere un input con questo id
const resultsContainer = document.getElementById('search-results'); // Contenitore per i risultati
const searchButton = document.getElementById('search-button'); // Pulsante di ricerca
const casinosContainer = document.getElementById('casinos'); // Contenitore per i casinò
let displayedCasinos = []; // Casinò attualmente mostrati
let totalDisplayed = 0; // Totale dei casinò mostrati

// Funzione per mostrare i risultati
function showResults(filteredCasinos) {
    resultsContainer.innerHTML = ''; // Pulisce i risultati precedenti

    if (filteredCasinos.length > 0) {
        filteredCasinos.forEach(casino => {
            const resultItem = document.createElement('div');
            resultItem.classList.add('result-item'); // Aggiungi una classe per lo stile
            resultItem.textContent = casino.name;
            resultsContainer.appendChild(resultItem);
        });
    } else {
        const noResults = document.createElement('div');
        noResults.classList.add('no-results');
        noResults.textContent = "Nessun casinò trovato.";
        resultsContainer.appendChild(noResults);
    }
}

// Azione per il pulsante di ricerca
searchButton.addEventListener('click', function() {
    const query = searchInput.value.toLowerCase().trim();
    if (query.length >= 2) {
        const filteredCasinos = casinos.filter(casino => casino.name.toLowerCase().startsWith(query));
        showResults(filteredCasinos);
    } else {
        resultsContainer.innerHTML = ''; // Pulisce i risultati se la query è troppo corta
    }
});

// Azione per il modulo di ricerca (per premere 'Enter')
searchInput.addEventListener('keypress', function(event) {
    if (event.key === 'Enter') {
        searchButton.click(); // Simula il click sul pulsante di ricerca
    }
});

// Funzione per mostrare i casinò
function showCasinos() {
    casinosContainer.innerHTML = ''; // Pulisce i casinò precedenti
    const toDisplay = casinos.slice(totalDisplayed, totalDisplayed + 10); // Prende i prossimi 10 casinò
    toDisplay.forEach(casino => {
        const casinoItem = document.createElement('div');
        casinoItem.classList.add('casino-item'); // Aggiungi una classe per lo stile
        casinoItem.textContent = casino.name;
        casinosContainer.appendChild(casinoItem);
    });
    totalDisplayed += toDisplay.length; // Aggiorna il totale mostrato

    // Se abbiamo mostrato tutti i casinò, nascondiamo il pulsante
    if (totalDisplayed >= 80 || totalDisplayed >= casinos.length) {
        document.querySelector('.more-button').style.display = 'none';
    }
}

// Mostra i primi 10 casinò all'avvio
showCasinos();

// Aggiungi funzionalità al pulsante "Mostra di più"
document.querySelector('.more-button').addEventListener('click', function() {
    showCasinos(); // Carica più casinò
});
