<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Casinò</title>
    <link rel="stylesheet" href="casinò.css">
    <script src="casinò.js" defer></script>
    <style>
        /* Stile per la finestra modale */
        .modal {
            display: none; /* Nascondi per impostazione predefinita */
            position: fixed; /* Posiziona in modo fisso */
            z-index: 1000; /* Soprattutto sopra altri elementi */
            left: 0;
            top: 0;
            width: 100%; /* Larghezza completa */
            height: 100%; /* Altezza completa */
            overflow: auto; /* Attiva lo scorrimento se necessario */
            background-color: rgb(0, 0, 0); /* Colore di sfondo traslucido */
            background-color: rgba(0, 0, 0, 0.4); /* Colore di sfondo con trasparenza */
        }

        .modal-content {
            background-color: #fefefe;
            margin: 15% auto; /* Margine per centrare */
            padding: 20px;
            border: 1px solid #888;
            width: 80%; /* Larghezza della finestra modale */
            max-width: 500px; /* Larghezza massima */
            border-radius: 8px; /* Angoli arrotondati */
        }

        .close-button {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close-button:hover,
        .close-button:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</head>
<body>

    <!-- Wrapper principale -->
    <div class="container">

        <!-- Sezione casinò in evidenza -->
        <aside class="featured">
            <h2>Casinò In Evidenza</h2>
            <div class="casino-featured">
                <div class="casino">
                    <a href="https://www.casino.com" target="_blank">
                        <img src="img/casino1.jpg" alt="Casino Featured 1">
                        <p>Descrizione breve del casinò in evidenza 1</p>
                    </a>
                </div>
                <div class="casino">
                    <a href="https://www.bovada.lv" target="_blank">
                        <img src="img/casino2.jpg" alt="Casino Featured 2">
                        <p>Descrizione breve del casinò in evidenza 2</p>
                    </a>
                </div>
            </div>
        </aside>

        <!-- Sezione centrale con la barra di ricerca e i casinò -->
        <main class="casino-list">
            <h2>Tutti i Casinò</h2>
            <!-- Barra di ricerca -->
            <div class="search-bar">
                <input type="text" placeholder="Cerca casinò..." aria-label="Cerca casinò">
                <button type="button">Cerca</button>
                <!-- Pulsante per aprire il filtro -->
                <button id="open-filter" type="button">Filtri</button>
            </div>

            <div id="casinos-container">
                <?php
                    $casinos = [
                        ['img' => 'img/casino1.jpg', 'descrizione' => 'Casino.com - Gioca a oltre 500 giochi!', 'link' => 'https://www.casino.com', 'tag' => 'Nuovo'],
                        ['img' => 'img/casino2.jpg', 'descrizione' => 'Bovada - Un casinò popolare negli USA.', 'link' => 'https://www.bovada.lv', 'tag' => 'Popolare'],
                        ['img' => 'img/casino3.jpg', 'descrizione' => '888 Casino - Un casinò famoso e affidabile.', 'link' => 'https://www.888.com', 'tag' => 'Affidabile'],
                        ['img' => 'img/casino4.jpg', 'descrizione' => 'LeoVegas - Casinò mobile premiato.', 'link' => 'https://www.leovegas.com', 'tag' => 'Mobile'],
                        ['img' => 'img/casino5.jpg', 'descrizione' => 'Royal Panda - Bonus generosi e giochi entusiasmanti.', 'link' => 'https://www.royalpanda.com', 'tag' => 'Bonus'],
                        ['img' => 'img/casino6.jpg', 'descrizione' => 'Casumo - Casinò innovativo con una vasta gamma di giochi.', 'link' => 'https://www.casumo.com', 'tag' => 'Innovativo'],
                        ['img' => 'img/casino7.jpg', 'descrizione' => 'Unibet - Casinò con ottimi giochi e scommesse sportive.', 'link' => 'https://www.unibet.com', 'tag' => 'Scommesse'],
                        ['img' => 'img/casino8.jpg', 'descrizione' => 'Betfair - Un altro grande nome nel mondo del gioco.', 'link' => 'https://www.betfair.com', 'tag' => 'Famoso'],
                        ['img' => 'img/casino9.jpg', 'descrizione' => 'Mr Green - Un casinò elegante e ben progettato.', 'link' => 'https://www.mrgreen.com', 'tag' => 'Elegante'],
                        ['img' => 'img/casino10.jpg', 'descrizione' => 'William Hill - Un marchio storico nel gioco.', 'link' => 'https://www.williamhill.com', 'tag' => 'Storico'],
                        ['img' => 'img/casino11.jpg', 'descrizione' => 'Bet365 - Ottimi giochi e un grande servizio clienti.', 'link' => 'https://www.bet365.com', 'tag' => 'Servizio'],
                        ['img' => 'img/casino12.jpg', 'descrizione' => 'EnergyCasino - Ottime offerte e giochi di alta qualità.', 'link' => 'https://www.energycasino.com', 'tag' => 'Offerte'],
                        ['img' => 'img/casino13.jpg', 'descrizione' => 'NetBet - Una piattaforma di gioco diversificata.', 'link' => 'https://www.netbet.com', 'tag' => 'Diversificato'],
                        ['img' => 'img/casino14.jpg', 'descrizione' => 'Mr Green - Design elegante e tanti giochi.', 'link' => 'https://www.mrgreen.com', 'tag' => 'Elegante'],
                        ['img' => 'img/casino15.jpg', 'descrizione' => 'Rizk - Un casinò con un tema unico.', 'link' => 'https://www.rizk.com', 'tag' => 'Unico'],
                        ['img' => 'img/casino16.jpg', 'descrizione' => 'SlotsMillion - Ottimo per gli appassionati di slot.', 'link' => 'https://www.slotsmillion.com', 'tag' => 'Slot'],
                        ['img' => 'img/casino17.jpg', 'descrizione' => 'BetVictor - Gioca e vinci con le scommesse.', 'link' => 'https://www.betvictor.com', 'tag' => 'Scommesse'],
                        ['img' => 'img/casino18.jpg', 'descrizione' => 'Paddy Power - Scommesse e casinò sotto lo stesso tetto.', 'link' => 'https://www.paddypower.com', 'tag' => 'Scommesse'],
                        ['img' => 'img/casino19.jpg', 'descrizione' => 'Guts - Casino con ottime recensioni.', 'link' => 'https://www.guts.com', 'tag' => 'Recensioni'],
                        ['img' => 'img/casino20.jpg', 'descrizione' => 'PlayOJO - Ottimo casinò senza requisiti di scommessa.', 'link' => 'https://www.playojo.com', 'tag' => 'Senza requisiti'],
                    ];

                    // Carica inizialmente i primi 20 casinò
                    for ($i = 0; $i < 20; $i++) {
                        echo '<div class="casino">';
                        echo '<a href="'.$casinos[$i]['link'].'" target="_blank">';
                        echo '<img src="'.$casinos[$i]['img'].'" alt="Casino">';
                        echo '<div class="casino-info">';
                        echo '<p>'.$casinos[$i]['descrizione'].'</p>';
                        echo '<span class="tag">'.$casinos[$i]['tag'].'</span>';
                        echo '</div>';
                        echo '</a>';
                        echo '</div>';
                    }
                ?>
            </div>

            <button id="load-more" type="button">Carica Altro</button>
        </main>

        <!-- Sezione delle news -->
        <aside class="news">
            <h2>Ultime Notizie</h2>
            <div class="news-item">
                <h3>Notizia 1</h3>
                <p>Descrizione breve della notizia 1.</p>
            </div>
            <div class="news-item">
                <h3>Notizia 2</h3>
                <p>Descrizione breve della notizia 2.</p>
            </div>
        </aside>
    </div>

    <!-- Finestra modale per i filtri -->
    <div id="filterModal" class="modal">
        <div class="modal-content">
            <span class="close-button">&times;</span>
            <h2>Filtri</h2>
            <form id="filter-form">
                <div>
                    <label for="deposit-method">Metodo di Deposito:</label>
                    <select id="deposit-method" name="deposit-method">
                        <option value="">Seleziona</option>
                        <option value="carta">Carta di Credito</option>
                        <option value="paypal">PayPal</option>
                        <option value="bitcoin">Bitcoin</option>
                        <option value="bonifico">Bonifico Bancario</option>
                    </select>
                </div>
                <div>
                    <label for="rating">Rating:</label>
                    <select id="rating" name="rating">
                        <option value="">Seleziona</option>
                        <option value="1">1.0</option>
                        <option value="2">2.0</option>
                        <option value="3">3.0</option>
                        <option value="4">4.0</option>
                        <option value="5">5.0</option>
                    </select>
                </div>
                <div>
                    <label for="license">Licenza:</label>
                    <select id="license" name="license">
                        <option value="">Seleziona</option>
                        <option value="mga">MGA</option>
                        <option value="ukgc">UKGC</option>
                        <option value="curacao">Curacao</option>
                    </select>
                </div>
                <div>
                    <label for="bonus">Bonus:</label>
                    <select id="bonus" name="bonus">
                        <option value="">Seleziona</option>
                        <option value="fino-a-100">Fino a 100€</option>
                        <option value="fino-a-200">Fino a 200€</option>
                        <option value="fino-a-500">Fino a 500€</option>
                    </select>
                </div>
                <div>
                    <label for="free-spins">Free Spins:</label>
                    <select id="free-spins" name="free-spins">
                        <option value="">Seleziona</option>
                        <option value="10">10 Spins</option>
                        <option value="20">20 Spins</option>
                        <option value="50">50 Spins</option>
                    </select>
                </div>
                <div>
                    <label for="country">Paese:</label>
                    <select id="country" name="country">
                        <option value="">Seleziona</option>
                        <option value="it">Italia</option>
                        <option value="fr">Francia</option>
                        <option value="es">Spagna</option>
                    </select>
                </div>
                <button type="submit">Applica Filtri</button>
            </form>
        </div>
    </div>

    <script>
        // Script per gestire la finestra modale
        const modal = document.getElementById("filterModal");
        const btn = document.getElementById("open-filter");
        const span = document.getElementsByClassName("close-button")[0];

        // Apri la finestra modale quando l'utente clicca sul pulsante
        btn.onclick = function() {
            modal.style.display = "block";
        }

        // Chiudi la finestra modale quando l'utente clicca sulla X
        span.onclick = function() {
            modal.style.display = "none";
        }

        // Chiudi la finestra modale se l'utente clicca al di fuori della finestra
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

        // Gestione dell'applicazione dei filtri
        document.getElementById('filter-form').addEventListener('submit', function(event) {
            event.preventDefault(); // Impedisci l'invio del modulo

            // Qui puoi gestire l'applicazione dei filtri e caricare i casinò filtrati
            const formData = new FormData(event.target);
            console.log("Filtri applicati:", Object.fromEntries(formData)); // Log dei filtri applicati

            // Chiudi la finestra modale dopo aver applicato i filtri
            modal.style.display = "none";
        });

        // Carica più casinò quando l'utente clicca sul pulsante
        let currentIndex = 20;
        const totalCasinos = <?php echo count($casinos); ?>; // Ottieni il numero totale di casinò
        document.getElementById("load-more").onclick = function() {
            for (let i = currentIndex; i < currentIndex + 20 && i < totalCasinos; i++) {
                const casino = `
                    <div class="casino">
                        <a href="${casinos[i]['link']}" target="_blank">
                            <img src="${casinos[i]['img']}" alt="Casino">
                            <div class="casino-info">
                                <p>${casinos[i]['descrizione']}</p>
                                <span class="tag">${casinos[i]['tag']}</span>
                            </div>
                        </a>
                    </div>
                `;
                document.getElementById("casinos-container").insertAdjacentHTML('beforeend', casino);
            }
            currentIndex += 20;
            if (currentIndex >= totalCasinos) {
                this.style.display = 'none'; // Nascondi il pulsante se non ci sono più casinò da caricare
            }
        };
    </script>
</body>
</html>
