// Aggiungi eventuali funzionalità JavaScript qui
document.addEventListener('DOMContentLoaded', function() {
    // Seleziona tutte le sezioni
    const sections = document.querySelectorAll('section');

    // Aggiungi una classe per l'animazione a ogni sezione
    sections.forEach((section, index) => {
        section.style.opacity = '0'; // Imposta l'opacità iniziale a 0
        section.style.transform = 'translateY(20px)'; // Posiziona le sezioni più in basso

        // Delay per ogni sezione
        setTimeout(() => {
            section.style.opacity = '1'; // Gradualmente rendi visibile la sezione
            section.style.transform = 'translateY(0)'; // Torna alla posizione originale
            section.style.transition = 'opacity 0.6s ease, transform 0.6s ease'; // Aggiungi la transizione
        }, index * 300); // Delay incrementale per l'effetto cascata
    });

    console.log('La pagina Chi Siamo è stata caricata correttamente.');
});
