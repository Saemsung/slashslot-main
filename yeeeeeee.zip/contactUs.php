<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contattaci</title>
    <link rel="stylesheet" href="contactUs.css">
</head>
<body>
    <div class="container">
        <h1 class="fade-in">Contattaci</h1>
        <p class="fade-in">Siamo qui per aiutarti! Se hai domande, commenti o suggerimenti, non esitare a contattarci. La tua opinione è fondamentale per noi e ci permette di migliorare continuamente i nostri servizi.</p>

        <h2 class="fade-in">Modalità di Contatto</h2>
        <p class="fade-in">Puoi contattarci facilmente tramite email. Clicca sul pulsante qui sotto per aprire direttamente il tuo client di posta elettronica. Il nostro indirizzo email sarà già inserito come destinatario, per permetterti di inviarci il tuo messaggio senza difficoltà.</p>

        <a href="https://mail.google.com/mail/?view=cm&fs=1&to=slashSlot@gmail.com" target="_blank" class="email-button fade-in">Scrivici via Email</a>

        <h2 class="fade-in">Orari di Risposta</h2>
        <p class="fade-in">Ci impegniamo a rispondere a tutte le email entro 24 ore durante i giorni feriali. Se hai bisogno di assistenza immediata, ti invitiamo a visitare la nostra sezione FAQ, dove potresti trovare risposte rapide alle domande più comuni.</p>

        <h2 class="fade-in">Seguici sui Social Media</h2>
        <p class="fade-in">Rimani aggiornato sulle ultime novità, offerte speciali e informazioni utili seguendoci sui nostri canali social:</p>
        <ul class="fade-in">
            <li><a href="#" target="_blank">Facebook</a></li>
            <li><a href="#" target="_blank">Twitter</a></li>
            <li><a href="#" target="_blank">Instagram</a></li>
        </ul>

        <p class="fade-in">Ti risponderemo il prima possibile. Grazie per averci contattato!</p>
    </div>
    <script src="scripts/contactUs.js"></script>
</body>
</html>
