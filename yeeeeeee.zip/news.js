document.addEventListener('DOMContentLoaded', () => {
    const newsItems = document.querySelectorAll('.news-item');

    // Aggiunge una classe per l'animazione
    newsItems.forEach((item, index) => {
        item.style.opacity = 0; // Nasconde l'elemento inizialmente
        item.style.transform = 'translateY(20px)'; // Sposta l'elemento leggermente verso il basso

        // Imposta un timeout per creare un effetto di ritardo progressivo
        setTimeout(() => {
            item.style.transition = 'opacity 0.5s ease-out, transform 0.5s ease-out';
            item.style.opacity = 1;
            item.style.transform = 'translateY(0)';
        }, index * 200); // Aggiunge un ritardo per ogni elemento
    });
});
