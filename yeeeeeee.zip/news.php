<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News Casinò</title>
    <link rel="stylesheet" href="news.css">
    <script src="news.js" defer></script>
</head>
<body>

    <div class="news-container">
        <h1 class="page-title">Ultime News sui Casinò</h1>
        <div class="news-row">
            <?php
            // Simulazione di 30 news riguardanti i casinò
            $news = [
                ['title' => 'Grande Vincita al Blackjack!', 'description' => 'Un giocatore ha vinto oltre 1 milione di euro giocando a Blackjack in un casinò online.', 'image' => 'img/blackjack.jpg', 'tags' => 'Blackjack, Vincita'],
                ['title' => 'Nuove Regolamentazioni sui Casinò', 'description' => 'Le nuove leggi impongono regole più severe ai casinò online per proteggere i giocatori.', 'image' => 'img/regulations.jpg', 'tags' => 'Regolamentazione, Sicurezza'],
                ['title' => 'Giocatore Vince al Mega Slot', 'description' => 'Un fortunato giocatore ha vinto il jackpot della mega slot con una puntata minima!', 'image' => 'img/slot.jpg', 'tags' => 'Slot, Jackpot'],
                ['title' => 'Guida ai Migliori Casinò del 2024', 'description' => 'Ecco una lista dei casinò online più sicuri e vantaggiosi per il 2024.', 'image' => 'img/casino2024.jpg', 'tags' => 'Guida, Casinò 2024'],
                // Copia questi dati per un totale di 30 news
            ];

            // Replicare gli stessi dati per simulare 30 articoli
            for ($i = 0; $i < 30; $i++) {
                $item = $news[$i % count($news)];
                echo '
                <div class="news-item">
                    <img src="' . $item['image'] . '" alt="' . $item['title'] . '">
                    <h2>' . $item['title'] . '</h2>
                    <p>' . $item['description'] . '</p>
                    <span class="tags">' . $item['tags'] . '</span>
                </div>';
            }
            ?>
        </div>
    </div>

</body>
</html>
